function getBotResponse(input) {
    if (input == "hi") {
        return "Hello there! How can I help you? Try asking questions. For example: (Ask \"my orders\", \"cancel my order\")";
    }
    if (input == "my orders") {
        return "Your can find my orders in: \"Menu > My orders\"";
    }

    if (input == "cancel my order") {
        return "You can cancel your orders by following these steps: \"Menu > My orders > Click on your order > Click on Cancel my order\" ";
    }

    if (input == "how can i change my account details") {
        return "You can change your account details by following these steps: \"Settings > My Account\"";
    }

    if (input == "thank you") {
        return "Have a Great Day! Continue shopping with us!";
    }
    // Simple responses
    if (input == "hello") {
        return "Hello there! How can I help you?";
    } else if (input == "goodbye") {
        return "Have a Great Day! Continue shopping with us!";
    }
    else if (input == "bye") {
        return "Have a Great Day! Continue shopping with us!";
    }
         else {
        return "Try asking something else!";
    }
}