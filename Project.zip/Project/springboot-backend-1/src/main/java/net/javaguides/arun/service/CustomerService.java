package net.javaguides.arun.service;

import java.util.List;

import net.javaguides.arun.model.Customer;

public interface CustomerService {
       Customer saveCustomer(Customer customer);
       List<Customer> getAllCustomers();
       Customer getCustomerById(long id);
       Customer UpdateCustomer(Customer customer, long id);
       void deleteCustomer(long id);
}
