package net.javaguides.arun.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="customers")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name="firstname")
	private String firstName;
	@Column(name="lastname")
	private String lastName;
	@Column(name="email")
	private String email;
	@Column(name="phone_no")
	private String phone_no;
	@Column(name="gender")
	private String gender;
	@Column(name="age")
	private int age;
	@Column(name="address")
	private String address;
	@Column(name="pincode")
	private int pincode;
	

}
